#include<stdio.h>
#include<ctype.h>
void main()
{
    int number;

    printf("Enter ASCII Value :- ");
    scanf("%d",&number);

    printf("The Value of is :- %d\n",number);
    printf("The Value of Alphabet is :- %c",number);


}