#include<stdio.h>
void main()
{
	char a='d';
	
	printf("%c\n",a);
}