#include<stdio.h>
#include<ctype.h>
void main()
{
	char a[50]="Red And White";

    printf("The Value of a:- %s",a);

}