#include<stdio.h>
#include<conio.h>
void main()
{
    char alpha;

    printf("Enter the Character : ");
    alpha = getchar();

    putchar(alpha);

}