#include<stdio.h>
void main()
{
	int cel,far;
	printf("Enter The Value of Degree Celsius= ");
	scanf("%d",&cel);

	far=cel*9/5+32;

	printf("Fahrenheit= %d\n",far);

}