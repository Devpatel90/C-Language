//integer

#include <stdio.h>

void main()
{
    int a=500;
    printf("The Value of a is %d\n",a);
}