//string

#include <stdio.h>

void main()
{
    char a[5]="Dev";
    printf("My Name is %s\n",a);
}