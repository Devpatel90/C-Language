//character

#include <stdio.h>

void main()
{
    char a='d';
    printf("My Name is %c\n",a);
}