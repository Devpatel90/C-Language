//float

#include <stdio.h>

void main()
{
    float a=45.69;
    printf("The Value of a is %f\n",a);
}