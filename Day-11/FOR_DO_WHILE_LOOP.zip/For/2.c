#include<stdio.h>
void main()
{
    int i;

    for(i=10;i>=1;i--)
    {
        printf("%d\n",i);
    }
}