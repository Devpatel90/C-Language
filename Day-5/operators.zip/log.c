#include <stdio.h>
void main()
{
	int a,b;
	printf("Enter the Value of a= ");
	scanf("%d",&a);
	printf("Enter the Value of b= ");
	scanf("%d",&b);
	printf("a && b : %d\n", a && b);
    printf("a || b : %d\n", a || b);
}