#include<stdio.h>
void main()
{
	int a=10;
	printf("The Value of a =%d\n",a );

}