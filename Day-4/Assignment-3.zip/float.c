#include<stdio.h>
void main()
{
	float a,b;

	printf("Enter the Value of a:- ");
	scanf("%f",&a);
	printf("Enter the Value of b:- ");
	scanf("%f",&b);

	printf("The Sum of a&b is:- %f",a+b);
}