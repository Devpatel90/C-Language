#include<stdio.h>
void main()
{
	char a;

	printf("Enter Your First letter:- ");
	scanf("%c",&a);
	printf("Answer is %c",a);

}