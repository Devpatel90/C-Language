#include<stdio.h>
void main()
{
	char a[10];

	printf("Enter Your Full Name:- ");
	scanf("%s",&a);
	printf("Your Name is %s",a);

}