#include <stdio.h>
void main()
{
	int a;
	printf("Enter the Value of a:-");
	scanf("%d",&a);
	printf("The Value of a is:-%d\n",a );
}