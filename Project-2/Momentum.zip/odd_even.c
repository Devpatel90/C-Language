#include<stdio.h>
void main()
{
	int a;

	printf("Enter Any Number:- ");
	scanf("%d",&a);

	a%2==0?printf("This Is Even Number \n"):printf("This Is Odd Number \n");
}